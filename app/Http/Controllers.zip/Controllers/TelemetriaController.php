<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Support\Facades\Auth;

use GuzzleHttp\Client;
#use GuzzleHttp\Psr7\Request;

class TelemetriaController extends Controller
{
    public function approve($id) {
        $user = User::find($id);

        $user->telemetria = 1;
        $user->save();

        return redirect()->route('admin.show');
    }
    public function index() {
        $groups = DB::connection('mysql_2')
                    ->table('cad_veiculo')
                    ->groupBy('cvei_obs')
                    ->get('cvei_obs');

        $plates = DB::connection('mysql_2')
                    ->table('cad_veiculo')
                    ->groupBy('cvei_placa')
                    ->get('cvei_placa');

        $login = DB::connection('mysql_2')
                    ->table('cad_motorista')
                    ->selectRaw('cmtr_login, cmtr_nome')
                    ->groupBy('cmtr_login')
                    ->get();
                    
        $user = Auth::user();
        
        if ($user->approv == 0) {
            return view('wait_for_approve');
        } else {
            if($user->telemetria == 1) {
                return view('telemetria.index', compact('groups', 'plates', 'login'));
            }
            else {
                return view('wait_for_approve');
            }
        }
    }

    public function filter(Request $request) {
        $data_I = $request->input('data_I');
        $data_F = $request->input('data_F');
        $group = $request->input('group');
        $plate_text = $request->input('plate_text');
        $plate_select = $request->input('plate_select');

        $horas_semana = 8;
        $horas_fds = 4;
        $hora_padrao = 0;

        //$date_interval = new DateInterval('P1D');
        //$periodo = new DatePeriod($data_I, $date_interval, $data_F);
        $periodo = CarbonPeriod::create($data_I, $data_F);

        $days = array();

        foreach($periodo as $p) {
            array_push($days, $p->format('l'));
        }
        
        //print_r($days);

        foreach($days as $d) {
            if ($d != "Sunday" && $d != "Saturday") {
                //print_r($horas_semana . " ");
                $hora_padrao += $horas_semana;
            }
            else if ($d == "Saturday") {
                //print_r($horas_fds . " ");
                $hora_padrao += $horas_fds;
            }
        }

        //print_r($hora_padrao . " ");

        if($group != null) {
            if($plate_select != null) {
                $query = DB::connection('mysql_2')
                            ->table('log_telemetria_veiculo')
                            ->join('cad_veiculo', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'cad_veiculo.cvei_id')
                            ->selectRaw('cad_veiculo.cvei_obs as Grupo, cad_veiculo.cvei_placa as Placa, sum(log_telemetria_veiculo.ltve_distancia) as KMTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_distancia) / sum(log_telemetria_veiculo.ltve_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_veiculo.ltve_inf_vel_seco) as VelMax, sum(log_telemetria_veiculo.ltve_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_veiculo.ltve_inf_frenagem) as Frenagem, sum(log_telemetria_veiculo.ltve_tempo_motor) as TempoMotor')
                            ->whereBetween('log_telemetria_veiculo.ltve_data', [$data_I, $data_F])
                            ->where('cad_veiculo.cvei_placa', '=', $plate_select)
                            ->where('cad_veiculo.cvei_obs', '=', $group)
                            ->groupBy('log_telemetria_veiculo.ltve_cvei_id')
                            ->orderBy('cad_veiculo.cvei_placa')
                            ->get();
            }
            else {
                $query = DB::connection('mysql_2')
                            ->table('log_telemetria_veiculo')
                            ->join('cad_veiculo', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'cad_veiculo.cvei_id')
                            ->selectRaw('cad_veiculo.cvei_obs as Grupo, cad_veiculo.cvei_placa as Placa, sum(log_telemetria_veiculo.ltve_distancia) as KMTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_distancia) / sum(log_telemetria_veiculo.ltve_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_veiculo.ltve_inf_vel_seco) as VelMax, sum(log_telemetria_veiculo.ltve_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_veiculo.ltve_inf_frenagem) as Frenagem, sum(log_telemetria_veiculo.ltve_tempo_motor) as TempoMotor')
                            ->whereBetween('log_telemetria_veiculo.ltve_data', [$data_I, $data_F])
                            ->where('cad_veiculo.cvei_obs', '=', $group)
                            ->groupBy('log_telemetria_veiculo.ltve_cvei_id')
                            ->orderBy('cad_veiculo.cvei_placa')
                            ->get();
            }
        }
        else {
            if($plate_text != null) {
                $query = DB::connection('mysql_2')
                            ->table('log_telemetria_veiculo')
                            ->join('cad_veiculo', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'cad_veiculo.cvei_id')
                            ->selectRaw('cad_veiculo.cvei_obs as Grupo, cad_veiculo.cvei_placa as Placa, sum(log_telemetria_veiculo.ltve_distancia) as KMTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_distancia) / sum(log_telemetria_veiculo.ltve_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_veiculo.ltve_inf_vel_seco) as VelMax, sum(log_telemetria_veiculo.ltve_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_veiculo.ltve_inf_frenagem) as Frenagem, sum(log_telemetria_veiculo.ltve_tempo_motor) as TempoMotor')
                            ->whereBetween('log_telemetria_veiculo.ltve_data', [$data_I, $data_F])
                            ->where('cad_veiculo.cvei_placa', '=', $plate_text)
                            ->groupBy('log_telemetria_veiculo.ltve_cvei_id')
                            ->orderBy('cad_veiculo.cvei_placa')
                            ->get();
            }
            else {
                $query = DB::connection('mysql_2')
                            ->table('log_telemetria_veiculo')
                            ->join('cad_veiculo', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'cad_veiculo.cvei_id')
                            ->selectRaw('cad_veiculo.cvei_obs as Grupo, cad_veiculo.cvei_placa as Placa, sum(log_telemetria_veiculo.ltve_distancia) as KMTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_distancia) / sum(log_telemetria_veiculo.ltve_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_veiculo.ltve_inf_vel_seco) as VelMax, sum(log_telemetria_veiculo.ltve_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_veiculo.ltve_inf_frenagem) as Frenagem, sum(log_telemetria_veiculo.ltve_tempo_motor) as TempoMotor')
                            ->whereBetween('log_telemetria_veiculo.ltve_data', [$data_I, $data_F])
                            ->groupBy('log_telemetria_veiculo.ltve_cvei_id')
                            ->orderBy('cad_veiculo.cvei_placa')
                            ->get();
            }
        }
        
        return view('telemetria.filtro', compact('query', 'hora_padrao'));
    }

    public function filter_driver(Request $request) {
        $data_I = $request->input('data_I');
        $data_F = $request->input('data_F');
        $login  = $request->input('login');

        $horas_semana = 8;
        $horas_fds = 4;
        $hora_padrao = 0;

        //$date_interval = new DateInterval('P1D');
        //$periodo = new DatePeriod($data_I, $date_interval, $data_F);
        $periodo = CarbonPeriod::create($data_I, $data_F);

        $days = array();

        foreach($periodo as $p) {
            array_push($days, $p->format('l'));
        }
        
        //print_r($days);

        foreach($days as $d) {
            if ($d != "Sunday" && $d != "Saturday") {
                //print_r($horas_semana . " ");
                $hora_padrao = $horas_semana;
            }
            else if ($d == "Saturday" || $d == "Sunday") {
                //print_r($horas_fds . " ");
                $hora_padrao = $horas_semana;
            }
        }


        $query = DB::connection('mysql_2')
                    ->table('log_telemetria_motorista')
                    ->join('cad_motorista', 'log_telemetria_motorista.ltmo_login', '=', 'cad_motorista.cmtr_login')
                    ->selectRaw('log_telemetria_motorista.ltmo_data as Data, cad_motorista.cmtr_nome as Motorista, sum(log_telemetria_motorista.ltmo_distancia) as KMTotal, sum(log_telemetria_motorista.ltmo_consumo) as ConsumoTotal, sum(log_telemetria_motorista.ltmo_consumo) as ConsumoTotal, sum(log_telemetria_motorista.ltmo_distancia) / sum(log_telemetria_motorista.ltmo_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_motorista.ltmo_inf_vel_seco) as VelMax, sum(log_telemetria_motorista.ltmo_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_motorista.ltmo_inf_frenagem) as Frenagem, sum(log_telemetria_motorista.ltmo_tempo_movimento) as TempoMovimento, sum(log_telemetria_motorista.ltmo_tempo_motor) as TempoMotor')
                    ->where('cad_motorista.cmtr_nome', '=', $login)
                    ->whereBetween('log_telemetria_motorista.ltmo_data', [$data_I, $data_F])
                    ->groupBy('log_telemetria_motorista.ltmo_data')
                    ->get();

        $jornada = DB::connection('mysql_2')
                                ->table('log_macro')
                                ->leftJoin('cad_motorista', 'log_macro.lmac_login', '=', 'cad_motorista.cmtr_login')
                                ->selectRaw('cad_motorista.cmtr_nome as Motorista, log_macro.lmac_cvei_id as Placa, log_macro.lmac_nome as Log, log_macro.lmac_data_gps as DataHora')
                                ->where('cad_motorista.cmtr_nome', '=', $login)
                                ->whereBetween('log_macro.lmac_data_gps', [$data_I, $data_F])
                                //->groupBy('log_macro.lmac_data_gps')
                                ->get();

        $dates = DB::connection('mysql_2')
                                            ->table('log_macro')
                                            ->leftJoin('cad_motorista', 'log_macro.lmac_login', '=', 'cad_motorista.cmtr_login')
                                            ->selectRaw('log_macro.lmac_cvei_id as Placa, log_macro.lmac_nome as Log, log_macro.lmac_data_gps as DataHora')
                                            //->where('cad_motorista.cmtr_nome', '=', $login)
                                            ->whereBetween('log_macro.lmac_data_gps', [$data_I, $data_F])
                                            //->groupBy('log_macro.lmac_data_gps')
                                            ->get();


        $xml = <<<XML
        <?xml version=\"1.0\" encoding=\"utf-8\"?>

        <soapenv:Envelope
        xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
        xmlns:ws="http://ws.sighra.com/">
        <soapenv:Header/>
        <soapenv:Body>
        <ws:obterMacros>
        <usuario>Setor.Desenvolvimento</usuario>
        <senha>APIPass</senha>
        <idMacro>1</idMacro>
        </ws:obterMacros>
        </soapenv:Body>
       </soapenv:Envelope>
       XML;

        $client = new Client();
        $options = [
            'headers' => [
                'Content-Type' => 'text/xml; charset=UTF8',
            ],
            'body' => $xml,
        ];

        $url = "http://201.16.220.217:9090/sighra-ws/sighraWS?xsd=1";

        $response = $client->request('POST', $url, $options);

        //$test = new SimpleXMLElement($xml);
        dd($response);

        return view('telemetria.filtro_driver', compact('query', 'days', 'horas_semana', 'horas_fds'));
    }

    public function filter_plate(Request $request) {
        $data_I = $request->input('data_I');
        $data_F = $request->input('data_F');
        $plate_text = $request->input('plate_text');
        $plate_select = $request->input('plate_select');

        $horas_semana = 8;
        $horas_fds = 4;
        $hora_padrao = 0;

        //$date_interval = new DateInterval('P1D');
        //$periodo = new DatePeriod($data_I, $date_interval, $data_F);
        $periodo = CarbonPeriod::create($data_I, $data_F);

        $days = array();

        foreach($periodo as $p) {
            array_push($days, $p->format('l'));
        }
        
        //print_r($days);

        foreach($days as $d) {
            if ($d != "Sunday" && $d != "Saturday") {
                //print_r($horas_semana . " ");
                $hora_padrao += $horas_semana;
            }
            else if ($d == "Saturday") {
                //print_r($horas_fds . " ");
                $hora_padrao += $horas_fds;
            }
        }

        if($plate_select != null) {
            $query = DB::connection('mysql_2')
                        ->table('log_telemetria_veiculo')
                        ->join('cad_veiculo', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'cad_veiculo.cvei_id')
                        ->leftJoin('log_telemetria', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'log_telemetria.ltel_cvei_id')
                        ->leftJoin('cad_motorista', 'log_telemetria.ltel_login', '=', 'cad_motorista.cmtr_login')
                        ->selectRaw('log_telemetria_veiculo.ltve_data as Data, cad_motorista.cmtr_nome as Motorista, cad_veiculo.cvei_placa as Placa, sum(log_telemetria_veiculo.ltve_distancia) as KMTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_distancia) / sum(log_telemetria_veiculo.ltve_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_veiculo.ltve_inf_vel_seco) as VelMax, sum(log_telemetria_veiculo.ltve_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_veiculo.ltve_inf_frenagem) as Frenagem, sum(log_telemetria_veiculo.ltve_tempo_movimento) as TempoMovimento, sum(log_telemetria_veiculo.ltve_tempo_motor) as TempoMotor')
                        ->where('cad_veiculo.cvei_placa', '=', $plate_select)
                        ->whereBetween('log_telemetria_veiculo.ltve_data', [$data_I, $data_F])
                        ->groupBy('log_telemetria_veiculo.ltve_data')
                        ->get();
        } else {
            $query = DB::connection('mysql_2')
                        ->table('log_telemetria_veiculo')
                        ->join('cad_veiculo', 'log_telemetria_veiculo.ltve_cvei_id', '=', 'cad_veiculo.cvei_id')
                        ->selectRaw('log_telemetria_veiculo.ltve_data as Data, cad_veiculo.cvei_placa as Placa, sum(log_telemetria_veiculo.ltve_distancia) as KMTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_consumo) as ConsumoTotal, sum(log_telemetria_veiculo.ltve_distancia) / sum(log_telemetria_veiculo.ltve_consumo) / 1000 as ConsumoMedio, sum(log_telemetria_veiculo.ltve_inf_vel_seco) as VelMax, sum(log_telemetria_veiculo.ltve_inf_vel_chuva) as VelMaxChuva, sum(log_telemetria_veiculo.ltve_inf_frenagem) as Frenagem, sum(log_telemetria_veiculo.ltve_tempo_movimento) as TempoMovimento, sum(log_telemetria_veiculo.ltve_tempo_motor) as TempoMotor')
                        ->where('cad_veiculo.cvei_placa', '=', $plate_text)
                        ->whereBetween('log_telemetria_veiculo.ltve_data', [$data_I, $data_F])
                        ->groupBy('log_telemetria_veiculo.ltve_data')
                        ->get();
        }
        
        
        return view('telemetria.filtro_plate', compact('query', 'hora_padrao'));
    }

    public function get_plate(Request $request, $id) {
        $q = $request->input('q');
        
        $plates = DB::connection('mysql_2')
                    ->table('cad_veiculo')
                    ->selectRaw('cad_veiculo.cvei_placa as Placa')
                    ->where('cad_veiculo.cvei_obs', '=', $q)
                    ->get();
        
        return $plates;
    }
}


        /* $months = array(
            "Janeiro" => "01",
            "Fevereiro" => "02",
            "Março" => "03",
            "Abril" => "04",
            "Maio" => "05",
            "Junho" => "06",
            "Julho" => "07",
            "Agosto" => "08",
            "Setembro" => "09",
            "Outubro" => "10",
            "Novembro" => "11",
            "Dezembro" => "12",
        );

        $years = [
            2023,
            2024,
            2025,
        ]; */
