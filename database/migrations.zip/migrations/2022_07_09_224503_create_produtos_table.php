<?php

use App\Models\Categoria;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('produtos', function (Blueprint $table) {
            $table->id();
            $table->string('nome');
            $table->text('descricao');
            //$table->string('linha');
            $table->text('comp_quimica')->nullable();
            $table->text('viscosidade')->nullable();
            $table->string('imagem');
            $table->string('tamanhos')->nullable();
            $table->string('ficha');
            $table->string('fispq');
            $table->foreignIdFor(Categoria::class);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('produtos');
    }
};
