@extends('layouts.app')

@section('content')

<div class="container">
    <h1 class="mx-auto mb-3">Permissão negada.</h1>
    <a class="btn bnt-danger" href="/">Voltar</a>
</div>

@endsection