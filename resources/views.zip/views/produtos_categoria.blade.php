@extends('layouts.app')

@section('content')

<x-navbar />

<style>
    #categorias {
        background: #F6F9FC;
    }
    #categorias:hover {
        background: red;
        color: white;
        transition: 0.4s;
    }
</style>



<img src="images/Banner - Produtos.png" style="width:100%" alt="">

<div class="container mb-5 mt-3">
    <a class="text-decoration-none" href="/" style="color: red;">HOME</a> > <a class="text-decoration-none text-dark" href="#">PRODUTOS</a>
</div>

<div clas="container mb-5">
    <h1 style="text-align: center; color: red"><strong>Nossos Produtos</strong></h1>
    <div class="container mt-4">
        <h5 class="mb-5" style="text-align: center; color:#A9ABAE">Mantenha o foco em seu destino, enquanto os produtos Dulub cuidam da performance, economia de combustível e vida útil do motor de seu veículo. 
                            A marca Dulub apresenta um portfolio completo de lubrificantes para o seu veículo, máquina ou equipamento.</h5>
    </div>
    
</div>

<div class="d-grid gap-2 col-9 mx-auto mb-5">
            <button class="btn" id="categorias" style="text-align:left; border-radius:0 !important;" type="button" data-bs-toggle="collapse" data-bs-target="#collapse" aria-expanded="false" aria-controls="collapse">
                {{ $categorias->nomeCategoria }}
            </button>
                    @foreach($produtos as $p)
                    <div class="card card-body mb-4" style="background-color: #F6F9FC; border-radius:0 !important;">
                            <div class="row" style="background-color: #F6F9FC;">
                                <div class="col">
                                    <img class="w-100 d-block" src="{{ asset($p->imagem) }}" alt="">
                                </div>
                                <div class="col-8 mt-5">
                                    @if( $p->id > 77 && $p->id < 82 )
                                        <h3 style="display: inline;"><strong>{{ substr($p->nome, 0 ,13) }}   </strong></h3>
                                        <h5 style="display: inline;"><strong>{{ substr($p->nome, 14) }}</strong></h5>
                                        <br><br>
                                    @else
                                        <h3 style="padding-right:50px"><strong>{{ $p->nome }}</strong></h3>
                                    @endif
                                    <p style="text-align:justify; padding-right:50px">{{ $p->descricao }}</p>
                                    @if($p->id != 82 && $p->id != 83)
                                        <p style="text-align:justify; padding-right:50px"><strong>Composição Química:</strong> {{ $p->comp_quimica }}</p>
                                    @endif
                                    @if($p->id < 69)
                                        <p><strong>VISCOSIDADE:</strong> {{ $p->viscosidade }}</p>
                                    @elseif($p->categoria_id == 8)
                                        <p><strong>GRAU NLGI:</strong> {{ $p->viscosidade }}</p>
                                    @endif
                                    <img class="d-block w-25 me-5" src="{{ asset($p->tamanhos) }}" alt="" style="float:right">
                                    <div class="container" style="float:right; margin-right:20px">
                                        <a class="btn me-3 mt-5 mb-4" href="{{ asset($p->ficha) }}" download style="color:white; background-color:#333333; float:right; border-radius:0 !important">Ver Ficha Técnica<i class="fa-light fa-list-tree"></i></a>
                                        <a class="btn me-3 mt-5 mb-4" href="#" style="color:white; background-color:red; float:right; border-radius:0 !important">BAIXAR FISPQ</a>
                                    </div> 
                                </div>
                            </div>
                    </div>
                    @endforeach
</div>

<img class="mb-5 d-block mx-auto" src="images/POWERED BY DULUB.png" alt="" style="width:15%;">


<x-footer/>