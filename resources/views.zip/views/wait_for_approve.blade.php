@extends('layouts.app')

@section('content')

    <x-navbar />
    
    <div class="d-flex aligns-items-center justify-content-center card text-center w-50 mx-auto" style="margin-top:250px">
        <div class="card-header">Cadastro Realizado
            <div class="card-body">
                <h3>Aguarde aprovação do seu gestor para poder acessar.</h3>
                
                        <form method="POST" action="/logout" enctype="multipart/form-data">
                            @csrf
                            
                            <button class="btn btn-danger mb-5" type="submit">Sair</button>
                        </form>
            </div>
        </div>
    </div>

@endsection
