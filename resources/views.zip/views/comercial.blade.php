@extends('layouts.app')

<x-navbar />

<img class="d-block w-100" src="images/Banner - Comercial.png" alt="">

<div class="container mb-5 mt-3">
    <a class="text-decoration-none" href="/" style="color: red">HOME</a> > <a class="text-decoration-none text-dark" href="#">COMERCIAL</a>
</div>

<div clas="container mb-5">
    <h1 style="text-align: center; color: red"><strong>Faça sua solicitação por aqui!</strong></h1>
    <div class="container mt-4">
        <h5 class="mb-5" style="text-align: center; color:#A9ABAE">É simples e rápido, basta seguir os passos abaixo:</h5>
    </div>  
</div>

<div class="container mb-5">
    <h4 style="text-align:center; color:#A9ABAE">
        • Clique no botão "CONTINUAR" abaixo;<br>
        <br>• Na página que abrir, passe o mouse em cima da etiqueta que contém "PÓS VENDA(v.1) ou “Cadastro de clienteV1”, conforme a sua necessidade e clique no botão "Iniciar" que irá aparecer. NÃO DEVE FAZER LOGIN! <br>
        <br>• Preencha o formulário de acordo com a sua necessidade, envie uma mensagem e anexe algum arquivo caso seja necessário; <br>
        <br>• Clique em "CONTINUAR" no final da página.
    </h4>
</div>

<div class="container mb-5 text-center">
    <a class="btn" href="https://dulub.orquestrabpm.com.br/workflow/wftoday.aspx" style="color:white; background:red; border-radius: 0" target="_blank">CONTINUAR</a>
</div>

<img class="mb-5 d-block mx-auto" src="images/POWERED BY DULUB.png" alt="" style="width:15%; margin-top:100px">





        <div id="footer" class="container-fluid" style="background-color: black; height:340px">
            <div class="container">
                <img class="d-block mx-auto mb-2 mt-3" src="images/Logo - Rodapé.svg" alt="" style="width:15%">
                <div class="container text-center mb-2">
                    <h3 style="display: inline; color:white"><strong>85</strong> </h3><h2 style="display: inline; color:white"><strong>3275.3070 / 0800 730 30 70</strong></h2>
                </div>
                <h6 class="text-center mb-4" style="color:white">
                    <a class="text-decoration-none me-2" href="/Comprar-Dulub" style="color:white">COMO COMPRAR</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Vender-Dulub" style="color:white">COMO VENDER</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Produtos" style="color:white">PRODUTOS</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Renox" style="color:white">ARLA 32</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Catalogos" style="color:white">DOWNLOADS</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Comercial" style="color:white">COMERCIAL</a> 
                </h6>
            </div>

            <div class="container-fluid" style="background:#0F0F0F">
                <h6 class="text-center" style="color:white; padding-top:15px; padding-bottom:15px">DUNAX LUBRIFICANTES LTDA. Núcleo CIS, Lote 02, Quadra 03 - S/N - São Gonçalo dos Campos - BA - CEP 44.330-000</h6>
            </div>
            
            <div class="container mt-4">
                <p style="text-align:center; font-size: 12px; color:white;">&copy 2022 Todos os direitos reservados.</p>
                <p style="text-align:center; font-size: 12px; color:white; margin-top:-15px;">Design by <a class="text-decoration-none" href="https://instagram.com/paulodsgnr">Paulo Vinícius</a> e Desenvolvimento por <a class="text-decoration-none" href="https://instagram.com/_lucasdsousa" _target="blank">Lucas Santana</a></p>
            </div>       
        </div>