@extends('layouts.app')

<style>
    .background {
        background-image: url('images/IMAGEM FUNDO - TRABALHE CONOSCO.png');
        background-position: center;
        height:1500px;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
    }
</style>

<x-navbar />


<div class="background">
    <div class="container text-justify" style="padding: 300px 0;">
            @if(!isset($jobs))
                @foreach($jobs as $j)
                    <div class="card mb-4" style="width: 70rem; border-radius: 0;">
                        <div class="card-body">
                            <h3 class="card-title" style="font-style: italic"><strong>{{ $j->title }}</strong></h3>
                            <h6 class="card-subtitle mb-2 text-muted">Vagas: {{ $j->vagas }}</h6>
                            <p class="card-text mb-4"><strong>LOCAL DE TRABALHO: </strong>{{ $j->local }}</p>
                            <p class="card-text mb-4"><strong>DESCRIÇÃO DE ATIVIDADES: </strong>{{ $j->descricao }}</p>
                            <p class="card-text mb-4"><strong>REQUISITOS: </strong>{{ $j->requisitos }}</p>
                            <p class="card-text mb-4"><strong>SALÁRIO: </strong>{{ $j->salario }}</p>
                            <p class="card-text mb-4"><strong>BENEFÍCIOS: </strong>{{ $j->beneficios }}</p>
                            <p class="card-text mb-4"><strong>HORÁRIO DE TRABALHO: </strong>{{ $j->jornada }}</p>
                            <button type="button" class="card-link btn" style="color:white; background:red; border-radius: 0;" data-bs-toggle="modal" data-bs-target="#curriculoModal{{ $j->id }}">Cadidatar-se</button>
                        </div>
                    </div>
    
                    <!-- Modal -->
                    <div class="modal fade" id="curriculoModal{{ $j->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="{{ route('enviar_curriculo') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Candidatura: <strong>{{ $j->title }}</strong></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    
                                    <div class="modal-body">
                                            <label class="form-label" id="basic-addon1">Nome Completo</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="name" aria-label="name" aria-describedby="basic-addon1" required>
                                            </div>
    
                                            <label class="form-label" id="basic-addon2">E-mail</label>
                                            <div class="input-group mb-3">
                                                <input type="email" class="form-control" name="email" aria-label="email" aria-describedby="basic-addon2"required>
                                            </div>
    
                                            <label class="form-label" id="basic-addon3">Telefone</label>
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="phone" id="basic-url" aria-describedby="basic-addon3"required>
                                            </div>
                                            
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="vaga" value="{{ $j->id }}" required style="display:none">
                                            </div>
                                            
                                            <div class="input-group mb-3">
                                                <input type="text" class="form-control" name="vaga_title" value="{{ $j->title }}" required style="display:none">
                                            </div>
    
                                            <label class="form-label">Currículo</label>
                                            <div class="input-group">
                                                <input type="file" class="form-control" name="resume" required>
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn" style="color:white; background: red; border-radius: 0;">Enviar Currículo</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="card mb-4" style="width: 70rem; border-radius: 0;">
                    <div class="card-body">
                        <h3 class="card-title" style="font-style: bold">Não há vagas disponiveis no momento.</h3>
                    </div>
                </div>
            @endif
            
    </div>
    <x-footer />
</div>

