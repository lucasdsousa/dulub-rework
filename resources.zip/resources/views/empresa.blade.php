@extends('layouts.app')

@section('content')

<x-navbar/>

<div class="container mb-5">
    <img class="mt-5 shadow mb-5 bg-body rounded" src="images/Banner A Dunax.png" alt="" style="width: 100%">
</div>

<!-- <h1 class="mb-5" style="text-align:center; color:red; font-size:48px"><strong>Sobre a nossa fábrica</strong></h1> -->

<div class="container">
    <h4 style="text-align: justify; color:#A9ABAE">Em duas décadas de história, a Dunax destaca-se nacionalmente como um dos maiores e mais importantes produtores de lubrificantes do país. Com Matriz situada na cidade de São Gonçalo dos Campos/BA, próximo ao Polo de petroquímico de Camaçari, a empresa possui um moderno parque fabril distribuídos em mais de 8.000,00 metros quadrados de área construídas implantadas em um terreno de 36.000,00 metros quadrados de área privada.</h4>

    <br>

    <h4 style="text-align: justify; color:#A9ABAE">A Dunax lubrificantes investe intensamente em infraestrutura e tecnologia de produção possibilitando, nos dias atuais, produzir 250 mil litros diários de lubrificantes. Os suportes dos nossos laboratórios na produção dos lubrificantes permitem que a Dunax entregue ao mercado produtos que atendem as mais rigorosas normas internacionais e padrões nacionais, estabelecidos e monitorados pela ANP.</h4>

    <br>

    <h4 style="text-align: justify; color:#A9ABAE">Para desenvolver lubrificantes de alta performance, a Dunax Lubrificantes submete os insumos e matérias primas a um rigoroso controle de qualidade, observando as melhores metodologias de estocagem e armazenamento dos materiais. O Processo de elaboração do lubrificante é supervisionado em todas as etapas da produção, afim de garantir a qualidade Dulub em nossos produtos finais.</h4>

    <br>

    <h4 style="text-align: justify; color:#A9ABAE">O nosso propósito é produzir e disponibilizar ao mercado uma completa linha de lubrificantes de alto padrão, observando sempre a economia, eficiência e performance que permite a Dulub ofertar lubrificantes vanguardista nos diversos nichos e seguimentos da lubrificação.</h4>

    <br>

    <h4 style="text-align: justify; color:#A9ABAE">A linha de lubrificantes Dulub foi desenvolvida para suprir as exigências e necessidades da indústria automobilística, maquinários e equipamentos em geral. O lubrificante Dulub é produzido dentro de rigorosos padrões de qualidade, utilizando-se de matérias primas especiais e selecionadas que permitem a Dunax entregar aos consumidores e clientes produtos de elevados padrões de qualidade e desempenho.</h4>

    <br>

    <h4 style="text-align: justify; color:#A9ABAE">O Uso do lubrificante correto é essencial para conservação, durabilidade e bom funcionamento do seu equipamento. Muito além de escolher o certo, investir em produtos que contemplem garantias de qualidade traz a segurança que você busca para seu veículo e/ou equipamento.</h4>

    <br>
</div>

<h1 class="mb-5" style="text-align:center; color:red; font-size:48px"><strong>Garantimos o que Produzimos</strong></h1>

<div class="container mb-5">
    <h4 style="text-align: justify; color:#A9ABAE">Na nossa indústria, todos os produtos passam por um criterioso processo de inspeção de qualidade que inicia na qualificação, certificações de produtos e fornecedores e finaliza com as etapas de produção assistidas por uma equipe técnica laboratorial que realiza mais de 30.000 analises mensais em lotes de lubrificantes. Um time comprometido e atuante que projeta o lubrificante Dulub para um padrão superior de conformidade e atendimento as normativas internacionais para que você tenha sempre o melhor lubrificante no seu veículo e/ou equipamento.</h4>
</div>

<div class="container">
    <img class="mb-5" src="images/Banner - A MARCA QUE MAIS CRESCE.png" alt="" style="width:100%; margin-top:100px">
</div>

<img class="mb-5 d-block mx-auto" src="images/POWERED BY DULUB.png" alt="" style="width:15%;">

<x-footer/>

@endsection