@extends('layouts.app')

<x-navbar />

<img class="d-block w-100" src="images/Banner - Comercial.png" alt="">

<div class="container mb-5 mt-3">
    <a class="text-decoration-none" href="/" style="color: red">HOME</a> > <a class="text-decoration-none text-dark" href="#">COMERCIAL</a>
</div>

<div clas="container mb-5">
    <h1 style="text-align: center; color: red"><strong>Faça sua solicitação por aqui!</strong></h1>
    <div class="container mt-4">
        <h5 class="mb-5" style="text-align: center; color:#A9ABAE">É simples e rápido, basta seguir os passos abaixo:</h5>
    </div>  
</div>

<div class="container mb-5">
    <h4 style="text-align:center; color:#A9ABAE">
        • Clique no botão "CONTINUAR" abaixo;<br>
        <br>• Na página que abrir, passe o mouse em cima da etiqueta que contém "PÓS VENDA(v.1) ou “Cadastro de clienteV1”, conforme a sua necessidade e clique no botão "Iniciar" que irá aparecer. NÃO DEVE FAZER LOGIN! <br>
        <br>• Preencha o formulário de acordo com a sua necessidade, envie uma mensagem e anexe algum arquivo caso seja necessário; <br>
        <br>• Clique em "CONTINUAR" no final da página.
    </h4>
</div>

<div class="container mb-5 text-center">
    <a class="btn" href="https://dulub.orquestrabpm.com.br/workflow/wftoday.aspx" style="color:white; background:red; border-radius: 0" target="_blank">CONTINUAR</a>
</div>

<img class="mb-5 d-block mx-auto" src="images/POWERED BY DULUB.png" alt="" style="width:15%; margin-top:100px">

<x-footer />