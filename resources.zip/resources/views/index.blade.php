@include('layouts.app')


@section('content')

<style>
  .container-img {
    position: relative;
    width: 25%;
    margin-bottom:50px;
  }
  
  .image {
    opacity: 1;
    display: block;
    width: 100%;
    height: auto;
    transition: .5s ease;
    backface-visibility: hidden;
  }
  
  .middle {
    position: absolute;
    top: 90%;
    left: 50%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
  }
  
  .container-img:hover .image {
    opacity: 0.3;
  }
  
  .container-img:hover .middle {
    opacity: 1;
  }
  
  .text {
    background-color: #04AA6D;
    color: white;
    font-size: 16px;
    padding: 16px 32px;
  }

  .img-centered {
    position: absolute;
    margin: auto;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
  }
    
  .carousel .carousel-indicators button {
      width:10px;
      height:10px;
      border-radius:100%;
      background-color:red;
      margin-right:7px;
    }

  @-webkit-keyframes scroll {
  0% {
  -webkit-transform: translateX(0);
  transform: translateX(0);
  }
  100% {
  -webkit-transform: translateX(calc(-250px * 7));
  transform: translateX(calc(-250px * 7));
  }
  }
  @keyframes scroll {
  0% {
  -webkit-transform: translateX(0);
  transform: translateX(0);
  }
  100% {
  -webkit-transform: translateX(calc(-250px * 7));
  transform: translateX(calc(-250px * 7));
  }
  }
  .slider {
  background: pr;
  box-shadow: 0 10px 20px -5px rgba(0, 0, 0, 0.125);
  height: 100px;
  margin: auto;
  overflow: hidden;
  position: relative;
  width: 1000px;
  }
  .slider::before, .slider::after {
  background: linear-gradient(to right, white 0%, rgba(255, 255, 255, 0) 100%);
  content: "";
  height: 100px;
  position: absolute;
  width: 200px;
  z-index: 2;
  }
  .slider::after {
  right: 0;
  top: 0;
  -webkit-transform: rotateZ(180deg);
  transform: rotateZ(180deg);
  }
  .slider::before {
  left: 0;
  top: 0;
  }
  .slider .slide-track {
  -webkit-animation: scroll 50s linear infinite;
  animation: scroll 50s linear infinite;
  display: flex;
  width: calc(250px * 14);
  }
  .slider .slide {
  height: 100px;
  width: 250px;
  }


</style>

<x-navbar/>

<div id="carouselBanners" class="carousel slide carousel-fade mb-5" data-bs-ride="true">
  <div class="carousel-indicators" style="bottom:-3.5rem;">
    <button type="button" data-bs-target="#carouselBanners" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselBanners" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselBanners" data-bs-slide-to="2" aria-label="Slide 3"></button>
    <button type="button" data-bs-target="#carouselBanners" data-bs-slide-to="3" aria-label="Slide 4"></button>
    <button type="button" data-bs-target="#carouselBanners" data-bs-slide-to="4" aria-label="Slide 5"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item">
      <img src="images/SITE IMAGE 12.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item active">
      <img src="images/SITE IMAGE 07.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item active">
      <img src="images/SITE IMAGE 10.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/SITE IMAGE 09.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/IMAGE 04.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselBanners" data-bs-slide="prev">
    <img src="images/SETA ESQUERDA.svg" alt="" style="width:15%">
    <span class="visually-hidden">Previous</span>
  </button>
  <button id="button_next" class="carousel-control-next" type="button" data-bs-target="#carouselBanners" data-bs-slide="next">
    <img src="images/SETA DIREITA.svg" alt="" style="width:15%">
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div class="container mb-5">
  <h1 class="mb-4" style="color:red; text-align:center; font-style:bold; margin-top:100px"><strong>Mantenha o foco em seu destino</strong></h1>
  <h5 style="text-align:center; color:#A9ABAE">Os produtos Dulub cuidam da performance, economia de combustível e durabilidade do seu veículo. A Dulub possui um portfólio completo de produtos automotivos.</h5>
</div>



<div id="carouselCategorias" class="carousel slide mb-5" data-bs-ride="true">
  <div class="carousel-indicators" style="bottom:-1rem;">
    <button type="button" data-bs-target="#carouselCategorias" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselCategorias" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselCategorias" data-bs-slide-to="2" aria-label="Slide 2"></button>
  </div>

  <div class="carousel-inner">

    <div class="carousel-item active">
      <div class="row container mx-auto">
        @foreach($cats as $c)
          @if($c->id < 5)
          <div class="container-img col">
            <img class="image" src="{{ asset($c->imagem) }}" alt="" style="width:100%">
            <div class="middle">
              <a class="btn d-block text-white text-nowrap" href="{{ route('produtos_categoria', $c->id) }}" style="background: red; font-weight: bold; border-radius: 0 !important; width:175px">{{ $c->nomeCategoria }}</a>
            </div>
          </div>
          @endif
        @endforeach
      </div>
    </div>

    <div class="carousel-item">
      <div class="row container mx-auto">
        @foreach($cats as $c)
          @if($c->id > 4 && $c->id < 9)
            <div class="container-img col">
              <img class="image" src="{{ asset($c->imagem) }}" alt="" style="width:100%">
              <div class="middle">
                <a class="btn d-block text-white text-nowrap" href="{{ route('produtos_categoria', $c->id) }}" style="background: red; font-weight: bold; border-radius: 0 !important; width:175px">{{ $c->nomeCategoria }}</a>
              </div>
            </div>
          @endif
        @endforeach
      </div>
    </div>

    <div class="carousel-item">
      <div class="row container mx-auto">
        @foreach($cats as $c)
          @if($c->id > 8)
            <div class="container-img col">
              <img class="image" src="{{ asset($c->imagem) }}" alt="" style="width:100%">
              <div class="middle">
                <a class="btn d-block text-white text-nowrap" href="{{ route('produtos_categoria', $c->id) }}" style="background: red; font-weight: bold; border-radius: 0 !important; width:175px">{{ $c->nomeCategoria }}</a>
              </div>
            </div>
          @endif
        @endforeach
      </div>
    </div>

  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#carouselCategorias" data-bs-slide="prev">
    <img src="images/SETA ESQUERDA.svg" alt="" style="width:15%">
    <span class="visually-hidden">Previous</span>
  </button>

  <button class="carousel-control-next" id="button_next2" type="button" data-bs-target="#carouselCategorias" data-bs-slide="next">
    <img src="images/SETA DIREITA.svg" alt="" style="width:15%">
    <span class="visually-hidden">Next</span>
  </button>
</div>

<div class="container-fluid">
  <img class="d-block w-100 mx-auto" src="images/Banner - A MARCA QUE MAIS CRESCE.png" alt="" style="width:100%; margin-top:40px">
</div>

<div class="container-fluid">
  <div class="row">
    <div class="col" style="background:#F6F9FC; align-items: right;">
      <h1 class="mt-5" style="color:red; text-align:right; margin-right:50px"><strong>QUER COMPRAR <br> LUBRIFICANTES DULUB <br> PARA SUA EMPRESA?</strong></h1>
      <br>
      <h5 style="text-align:right; margin-right:50px">Contate nossos distribuidores e garanta mais <br> proteção, produtividade e economia com os <br> lubrificantes Dulub.</h5>
      <br><br>
        <a class="btn mb-5" href="/Comprar-Dulub" style="color:white; background-color:red; float: right; margin-right:50px; border-radius:0 !important"><strong>FALE COM UM DE NOSSOS CONSULTORES</strong></a>
    </div>
    <div class="col" style="background:red">
      <h1 class="mt-5" style="color: white; margin-left:50px"><strong>QUERO VENDER <br> DULUB</strong></h1>
      <br><br><br>
      <h5 style="color: white; margin-left:50px">Conheça nossos distribuidores autorizados e <br> vire um parceiro da Dulub no Brasil.</h5>
      <br><br><br>
      <a class="btn mb-5" href="/Vender-Dulub" style="background-color: #F6F9FC; margin-left:50px; border-radius:0 !important"><strong>FALE COM NOSSA EQUIPE</strong></a>
    </div>
  </div>
</div>

<div class="container mb-5">
  <div class="row align-items-center">
    <div class="col">
      <img class="d-block mx-auto" src="images/Logo Dunax H.png" alt="" style="width: 75%;">
      <h5 style="color:#A9ABAE; text-align:justify; margin-top:-30px; hyphens: auto;">
        Fundada no início dos anos 2000 com o propósito de desenvolver lubrificantes de última 
        geração para automóveis, máquinas e equipamentos, a Dunax lubrificantes disponibiliza ao 
        mercado uma gama diversificada de produtos de qualidade superior e tecnologia avançada.
        Os lubrificantes Dulub são comercializados em todo território nacional por uma rede de 
        distribuição própria que conta com dezoitos centros comerciais e uma infraestrutura 
        logística com mais de 220 caminhões otimizados para atender as mais diversificadas situações 
        de transportes e cargas.
      </h5>
      <br>
      <a class="btn" href="/Empresa" style="background-color:red; color:white; border-radius:0 !important; float: right;">Saiba mais</a>
    </div>
    <div class="col mt-5" style="margin-left:100px">
      <img src="images/FACHADA FÁBRICA - Imagem meramente ilustrativa.png" alt="" style="width: 100%">
    </div>
  </div>
</div>

<br>

<img src="images/Banner site - INSTA.png" alt="" style="width:100%; margin-bottom:-100px">
<a class="btn mt-3 mb-5" href="https://www.instagram.com/duluboficial/" target="_blank" style="background-color:red; color:white; border-radius:0 !important; margin-left:800px;">Ver perfil</a>

<strong><h1 class="mt-5 mb-5 text-center" style="color:red;"><strong>Conheça nosso canal no YouTube</strong></h1></strong>

<div class="container" style="display:flex; align-items:center; justify-content:center;">
  <iframe style="width:75%;" width="1366" height="482" src="https://www.youtube.com/embed/8UPTLako7oc" title="Dulub - Tecnologia Fluida" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>

<img class="mt-5" src="images/Banner - Renox Arla 32.png" alt="" style="width: 100%;">
<a class="btn" href="/Renox" style="color:white; background:#42B219; border-radius: 0 !important; margin-left:350px; margin-top:-175px"><strong>Saiba mais</strong></a>

<div class="container-fluid" style="background-color: white; margin-top:-25px">
  <div class="container mb-5">
    <br><br><br>
    <h1 style="text-align: center; color: red"><strong>Supply Partners</strong></h1>
    <div class="slider">
      <div class="slide-track">
        <div class="slide">
          <img src="images/parceiros/Logo - Petrobrás.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Adnoc.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Chevron.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - acelem.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Afton.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - DYM.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Penthol.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Quantiq.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Lwart.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Petrobrás.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Adnoc.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Chevron.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - acelem.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Afton.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - DYM.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Penthol.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Quantiq.png" class="d-block" alt="..." style="width:85%">
        </div>
        <div class="slide">
          <img src="images/parceiros/Logo - Lwart.png" class="d-block" alt="..." style="width:85%">
        </div>
      </div>
    </div>
  </div>
</div>


        <style>    
            #footer {
                padding: 10px 10px 0px 10px;
                bottom: 0;
                width: 100%;
            }     

            hr {
                color: white;
                border: solid 1px white;
                border-radius: 100px;
                width: 1000px;
                margin-right: auto;
                margin-left: auto;
        }
        </style>

        <div id="footer" class="container-fluid" style="background-color: black; height:340px">
            <div class="container">
                <img class="d-block mx-auto mb-2 mt-3" src="images/Logo - Rodapé.svg" alt="" style="width:15%">
                <div class="container text-center mb-2">
                    <h3 style="display: inline; color:white"><strong>85</strong> </h3><h2 style="display: inline; color:white"><strong>3275.3070 / 0800 730 30 70</strong></h2>
                </div>
                <h6 class="text-center mb-4" style="color:white">
                    <a class="text-decoration-none me-2" href="/Comprar-Dulub" style="color:white">COMO COMPRAR</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Vender-Dulub" style="color:white">COMO VENDER</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Produtos" style="color:white">PRODUTOS</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Renox" style="color:white">ARLA 32</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Catalogos" style="color:white">DOWNLOADS</a> | 
                    <a class="text-decoration-none me-2 ms-2" href="/Comercial" style="color:white">COMERCIAL</a> 
                </h6>
            </div>

            <div class="container-fluid" style="background:#0F0F0F">
                <h6 class="text-center" style="color:white; padding-top:15px; padding-bottom:15px">DUNAX LUBRIFICANTES LTDA. Núcleo CIS, Lote 02, Quadra 03 - S/N - São Gonçalo dos Campos - BA - CEP 44.330-000</h6>
            </div>
            
            <div class="container mt-4">
                <p style="text-align:center; font-size: 12px; color:white;">&copy 2022 Todos os direitos reservados.</p>
                <p style="text-align:center; font-size: 12px; color:white; margin-top:-15px;">Design by <a class="text-decoration-none" href="https://instagram.com/paulodsgnr">Paulo Vinícius</a> e Desenvolvimento por <a class="text-decoration-none" href="https://instagram.com/_lucasdsousa" _target="blank">Lucas Santana</a></p>
            </div>       
        </div>


<script>
  document.getElementById('button_next').click();
  document.getElementById('button_next2').click();
</script>

