<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

        <!-- Scripts -->
        <script src="https://kit.fontawesome.com/0043fbe818.js" crossorigin="anonymous"></script>

        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            @include('layouts.navigation')

            <!-- Page Heading -->
            @if (isset($header))
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        {{ $header }}
                    </div>
                </header>
            @endif

            <!-- Page Content -->
            <main>
                <div class="container mt-5">
                    <button class="btn btn-outline-primary mx-3" id="rel-geral" type="button">Relatório Geral</button>
                    <button class="btn btn-outline-success mx-3" id="rel-driver" type="button">Individual Motorista</button> <span class="badge bg-secondary">Em Desenvolvimento</span>
                    <button class="btn btn-outline-danger mx-3" id="rel-plate" type="button">Individual Placa</button> <span class="badge bg-secondary">Em Desenvolvimento</span>
                </div>

                <div class="row container">
                    <div class="col" id="div-geral" style="display: none">
                        <form class="mt-5" method="GET" action="{{ route('filtrar') }}" enctype="multipart/form-data">
                            @csrf

                            <!-- Data Address -->
                            <div class="col-sm-3 mb-2">
                                <x-input-label for="data_I" :value="__('Data Inicial')" />
                                <x-text-input id="data_I" class="block mt-1" type="date" name="data_I" :value="old('data_I')" required />
                            </div>

                            <div class="col-sm-3 mb-2">
                                <x-input-label for="data_F" :value="__('Data Final')" />
                                <x-text-input id="data_F" class="block mt-1" type="date" name="data_F" :value="old('data_F')" required />
                            </div>
                            
                            <div class="row mb-2" id="group">
                                <div class="col-sm-6">
                                    <x-input-label for="group" :value="__('Grupo')" />
                                    <select class="form-select" name="group" aria-label="Grupo">
                                        <option disabled>Grupo</option>
                                        @foreach($groups as $g)
                                            <option value="{{ $g->cvei_obs }}">{{ htmlspecialchars($g->cvei_obs) }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-3 mb-2" id="plate_text">
                                <x-input-label for="plate_text" :value="__('Placa')" />
                                <x-text-input class="block mt-1" type="text" name="plate_text" :value="old('plate_text')" />
                            </div>

                            <div class="flex items-center justify-start mt-4">
                                <x-primary-button class="ml-3">
                                    {{ __('Buscar') }}
                                </x-primary-button>
                            </div>
                        </form>
                    </div>

                    <div class="col" id="div-motorista" style="display: none">
                        <form class="mt-5" action="{{ route('filtrar_motorista') }}" method="GET" enctype="multipart/form-data">
                            @csrf
                            
                            <div class="col-sm-3 mb-2">
                                <x-input-label for="data_I" :value="__('Data Inicial')" />
                                <x-text-input id="data_I" class="block mt-1" type="date" name="data_I" :value="old('data_I')" required />
                            </div>

                            <div class="col-sm-3 mb-2">
                                <x-input-label for="data_F" :value="__('Data Final')" />
                                <x-text-input id="data_F" class="block mt-1" type="date" name="data_F" :value="old('data_F')" required />
                            </div>

                            <div class="row mb-2">
                                <div class="col-sm-8">
                                    <x-input-label for="login" :value="__('Motorista')" />
                                    <select class="form-select" name="login" id="login" aria-label="Grupo">
                                        <option disabled>Motorista</option>
                                        @foreach($login as $l)
                                            <option value="{{ $l->cmtr_login }}">{{ $l->cmtr_nome }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="flex items-center justify-start mt-4">
                                <x-primary-button class="ml-3">
                                    {{ __('Buscar Motorista') }}
                                </x-primary-button>
                            </div>
                        </form>
                    </div>

                    <div class="col" id="div-placa" style="display: none">
                        <form class="mt-5" method="GET" action="{{ route('filtrar_placa') }}" enctype="multipart/form-data">
                            @csrf

                            <!-- Data Address -->
                            <div class="col-sm-3 mb-2">
                                <x-input-label for="data_I" :value="__('Data Inicial')" />
                                <x-text-input id="data_I" class="block mt-1" type="date" name="data_I" :value="old('data_I')" required />
                            </div>

                            <div class="col-sm-3 mb-2">
                                <x-input-label for="data_F" :value="__('Data Final')" />
                                <x-text-input id="data_F" class="block mt-1" type="date" name="data_F" :value="old('data_F')" required />
                            </div>

                            <div class="col-sm-3 mb-2" id="plate_text">
                                <x-input-label for="plate_text" :value="__('Placa')" />
                                <x-text-input class="block mt-1" type="text" name="plate_text" :value="old('plate_text')" />
                            </div>

                            <div class="flex items-center justify-start mt-4">
                                <x-primary-button class="ml-3">
                                    {{ __('Buscar Placa') }}
                                </x-primary-button>
                            </div>
                        </form>
                    </div>
                </div>
            </main>
        </div>
        

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

        <script>
            $(document).ready(function(){
                $('#group').on('change', function(){
                    var demovalue = $(this).val();

                    if(demovalue != "") {
                        $("#plate_select").hide();
                        $("#plate_text").hide();
                    }
                    else {
                        $("#plate_select").hide();
                        $("#plate_text").show();
                    }
                });
                
                $("#plate_select").on('change', function(){            
                    $("#plate_text").hide();          
                    $("#group").hide();
                });
                
                $("#plate_text").on('change', function(){            
                    $("#plate_select").hide();       
                    $("#group").hide();
                });
                
                $('#rel-geral').on('click', function(){             
                    $("#div-geral").show();         
                    $("#div-motorista").hide();   
                    $("#div-placa").hide();
                });

                $('#rel-driver').on('click', function(){    
                    $("#div-motorista").show();           
                    $("#div-geral").hide();   
                    $("#div-placa").hide();
                });

                $('#rel-plate').on('click', function(){      
                    $("#div-placa").show();        
                    $("#div-geral").hide();           
                    $("#div-motorista").hide();
                });
                
            });
        </script>

        <!--
        <script>
            function showUser(str) {
            if (str == "") {
                document.getElementById("plate_select").innerHTML = "";
                return;
            } else {
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("plate_select").innerHTML = this.responseText;
                }
                };
                xmlhttp.open("GET","getuser.php?q="+str,true);
                xmlhttp.send();
            }
            }
        </script> -->
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    </body>
</html>